<?php
    require 'db.php';
    $id = $_GET['vid'];
    $query = "select * from volunteer where vid = '$id' ";
    $result=mysqli_query($conn,$query);
    while($row=mysqli_fetch_array($result)){
        
            $name = $row['name'];
            $password = $row['password'];
            $address = $row['address'];
            $phone = $row['phone'];
            $query1 = "INSERT INTO agent(agent_id,name,password,address,phone) 
            VALUES (NULL,'$name', '$password', '$address', '$phone');";
    $result1=mysqli_query($conn,$query1);
        
        if($result1){
            echo "<script>alert('Successfully to added agent')</script>";
        }else{
            echo "<script>alert('Unknown error occured')</script>";
        

    }
    $q="delete from volunteer where vid='$id'";
    $result2=mysqli_query($conn,$q);
}
    

?>
