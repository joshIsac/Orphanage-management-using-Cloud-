<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .login{
            text-align:center;
            padding:50px;
        }
        .btn-1{
 	display: inline-block;
 	background: black;
 	color: #fff;
 	padding: 8px 30px;
 	margin: 30px 0;
 	border-radius: 20px;
 	
 }
 .btn-1:hover{
 	background: #563434;

 }
 
        </style>
</head>
<body>
    <form action=" " method="POST">
        <div class="login">
            <b>LOGIN<br>
       <b>Name <input type="text" name="name" required>
       <b>Password<input type="password" name="pass"required>
       <input type="submit" name="submit" class="btn-1" value="login">
       
</div>
</form>
</body>
</html>
<?php
require 'db.php';
if(isset($_POST['submit'])){
$name=$_POST['name'];
$password=$_POST['pass']; 
$sql="select * from admin where username='$name' AND password='$password'";
$result=mysqli_query($conn,$sql) or die('error');
if(mysqli_num_rows($result)==1){
    header("location:admin_profile.php");
}
else{
    echo"Try Again! Username And Password Is Incorrect";
}
mysqli_close($conn);
}
?>