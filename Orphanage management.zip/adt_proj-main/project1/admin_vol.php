<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   
</head>
    <h1 align="center">VOLUNTEERS</h1>
<body bgcolor="#ffffb3">
    <?php
      require 'db.php'; 
      
      $sql="select *from volunteer";
      $result=mysqli_query($conn,$sql) or die('error');
      if(mysqli_num_rows($result)==0){
        echo"<p align='center'>There are No Volunteers</p>";
    }
     ?>
          <table border='1' width='80%' align='center'>
              
          

          <th>image</th>
          <th>name</th>
          <th>age</th>
          <th>phone</th>
          <th>address</th>
          <th>Add</th>
          <th>delete</th>
          
             
          <?php while($row=mysqli_fetch_array($result)):  ?>
            <tr bgcolor='orange' align="center">
                <td><img src='images/<?php echo $row['image'];?> '></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['age']; ?></td>
                <td><?php echo $row['phone']; ?></td>
                <td><?php echo $row['address']; ?></td>
                <td><a href="accept.php?vid=<?php echo $row['vid'] ?>">Accept</a></td>
                <td><a href="reject.php?vid=<?php echo $row['vid'] ?>">Reject</a></td>
      </div>
            
     </tr>
     <?php endwhile;?>  
     

</body>
</html>

    
