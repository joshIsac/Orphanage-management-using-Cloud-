<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
          body{
            text-align: left;
    font-size: 20px;
    padding: 300px;
    color: white;
    
    background-image:url(images/fooddonate.jpg);
    background-size:cover;
    background-attachment: fixed;
    background-position: center;
        }
        .apply{
            width: 400px;
            height: 620px;
            background: rgba(0, 0, 0, 0.3);
            color: #ccffff;
            top: 50%;
            left: 50%;
            position: absolute;
            transform: translate(-50%,-50%);
            box-sizing: border-box;
            padding:  30px;
            border-radius: 20px;
        }
        .field{
            height: 20px;
	        font-size: 15px;
	        margin:20px 0 20px 0;
	        width: 250px;
             
        }
        .btn-1{
 	        display: inline-block;
 	        background: black;
 	        color: #fff;
 	        padding: 8px 30px;
 	        margin: 2px 0;
 	        border-radius: 20px;
        }
        </style>
</head>
<body>
    <form action=" " class="apply" method="POST">
        
        <b>Name <br><input type="text"  name="name" class="field" required><br>
        <b>Email <br><input type="email" name="email" class="field" required><br>
       <b>Address <br><input type="text" name="address" class="field" required><br>
       <b>Contactno<br> <input type="text" name="phone" class="field" required><br>
    Type Of Food<br>
    <input type="text" name="food" class="field" required><br>
    Quantity<br>
    <input type="text" name="quantity" class="field" required><br>
<input type="submit" name="submit" class="btn-1">

</form>
</body>
</html>
<?php
require 'db.php';
if(isset($_POST['submit'])){
$name=$_POST['name'];
$email=$_POST['email'];
$address=$_POST['address']; 
$phone=$_POST['phone'];
$donate=$_POST['food'];
$quantity=$_POST['quantity'];
$sql="INSERT INTO donate(name,email,address,phone,donatingitem,quantity)VALUES('$name','$email','$address','$phone','$donate','$quantity')";
$result=mysqli_query($conn,$sql);
    if($result){
       echo"<script>alert('Information shared successfully.Wait for admin message')</script>";
    } 
    
}
?> 
