<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
require 'db.php';
if(isset($_POST['submit'])){
$name=$_POST['name'];
$Password=$_POST['pass']; 
$sql="select * from donor_login where username='$name' AND password='$Password'";
$result=mysqli_query($conn,$sql) or die('error');
if(mysqli_num_rows($result)==1){
    echo"HELLO $name";
}
else{
    echo"Try Again! Username And Password Is Incorrect";
}
mysqli_close($conn);

}
?>
</body>
</html>


