<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<p>ugduigs</p>
<body>

   
    <?php
    require 'db.php';
        $id = $_GET['agent_id'];
        $sql="select * from agent where agent_id='$id'";
        $result=mysqli_query($conn,$sql) or die('error');
        while($row=mysqli_fetch_array($result)){
            echo"<table border='1' width='80%' align='center'><th bgcolor='rgba(0, 0, 0, 0.3)'>message</th>
           
            <tr bgcolor='orange'>
            
             <td width='20%'><p align='center'>".$row['message']."</p></td></tr></table>";
    }

    ?>
</body>
</html>
