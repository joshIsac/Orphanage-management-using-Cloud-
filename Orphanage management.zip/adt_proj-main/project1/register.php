<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            background:#ffffb3;
            background-size:cover;
            background-attachment: fixed;
            background-position: center;
        }
        .apply{
    background: #fff;
	width: 300px;
	height: 200px;
	position: relative;
	text-align: center;
	padding: 20px 0;
	margin: auto;
	box-shadow: 0 0 20px 0px rgba(0,0,0,0.1); 
	overflow: hidden;
}
.btn-1{
 	    display: inline-block;
 	    background: black;
 	    color: #fff;
 	    padding: 8px 30px;
 	    border-radius: 10px;
 }
 .btn-1:hover{
 	background: white;
     color:black;

 }
 .text-center{
	    text-align: center;
    }
    .login{
	width: 30%;
	border: 2px solid grey;
	margin: 10% auto;
	padding: 25px 0;
	background: radial-gradient(#fff,#ffd6d6);
}
        </style>
</head>
<body>

<div class="login">
    <h1 align="center">DONOR REGISTER</h1>
    <div class="apply">
<form action=" " class="text-center" method="POST">
    <b>Username <input type="text" name="name" required><br><br>
       <b>Password <input type="password" name="pass" required><br><br>
       <b>Address <input type="text" name="address" required><br><br>
       <b>Phone number <input type="text" name="phone" required><br><br>
       <input type="submit" name="signup" class="btn-1">
</div>
</div>
</form>
</body>
</html>
<?php
require 'db.php';
if(isset($_POST['signup'])){
    $username=$_POST['name'];
    $password=$_POST['pass'];
    $address=$_POST['address'];
    $phone=$_POST['phone'];

    $sql="INSERT INTO donor(username,password,address,phone)VALUES('$username','$password','$address','$phone')";
    $result=mysqli_query($conn,$sql);
    if($result){
        header("location:donor.php");
    }
}
?>