<?php
   require 'db.php';
    $id = $_GET['vid'];
    
    
    $query = "DELETE FROM volunteer WHERE vid = '$id' ";
    $res=mysqli_query($conn,$query);
        if($res){
            echo "<script>alert('Account Has Been Rejected')</script>";
        }else{
            echo "<script>alert('Unknown error occured')</script>";
        }

?>
<br/><br/>
<a href="admin_vol.php">Back</a>